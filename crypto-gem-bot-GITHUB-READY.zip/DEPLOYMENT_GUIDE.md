# 🚀 Guía Completa de Despliegue - Crypto Gem Bot

Esta guía te llevará paso a paso para desplegar tu bot detector de gemas crypto en Railway con dominio real y funcionamiento 24/7.

## 🎯 Opción Recomendada: Railway

Railway es la plataforma más confiable para este tipo de aplicaciones porque:
- **Despliegue automático** desde GitHub
- **Dominio gratuito** incluido
- **Escalado automático** según demanda
- **99.9% uptime** garantizado
- **SSL/HTTPS** automático
- **Variables de entorno** seguras

## 📋 Requisitos Previos

### 1. Cuenta de GitHub
- Crea una cuenta en [GitHub.com](https://github.com) si no tienes
- Verifica tu email

### 2. Cuenta de Railway
- Ve a [Railway.app](https://railway.app)
- Regístrate con tu cuenta de GitHub
- Verifica tu cuenta

### 3. APIs Necesarias
- **Binance API Keys** (para trading real)
- **Telegram Bot Token** (para alertas)

## 🔧 Paso 1: Preparar el Repositorio

### Opción A: Fork del Repositorio Original
1. **Ve al repositorio** original del bot
2. **Haz clic en "Fork"** (esquina superior derecha)
3. **Selecciona tu cuenta** como destino
4. **Espera** a que se complete el fork

### Opción B: Crear Repositorio Nuevo
1. **Crea nuevo repositorio** en GitHub
2. **Sube todos los archivos** del bot:
   - `app.py`
   - `requirements.txt`
   - `Procfile`
   - `railway.json`
   - `.env.example`
   - `README.md`
   - `.gitignore`

## 🚀 Paso 2: Desplegar en Railway

### 2.1 Conectar Repositorio
1. **Inicia sesión** en [Railway.app](https://railway.app)
2. **Haz clic en "New Project"**
3. **Selecciona "Deploy from GitHub repo"**
4. **Autoriza Railway** a acceder a tu GitHub
5. **Selecciona el repositorio** del bot
6. **Haz clic en "Deploy Now"**

### 2.2 Configurar Variables de Entorno
1. **Ve a tu proyecto** en Railway
2. **Haz clic en "Variables"**
3. **Añade las siguientes variables**:

```
FLASK_ENV=production
SECRET_KEY=crypto-bot-secret-2024-tu-clave-unica
BINANCE_API_KEY=tu_binance_api_key_aqui
BINANCE_API_SECRET=tu_binance_api_secret_aqui
TELEGRAM_BOT_TOKEN=tu_telegram_bot_token_aqui
TELEGRAM_CHAT_ID=tu_telegram_chat_id_aqui
```

### 2.3 Verificar Despliegue
1. **Espera** a que termine el build (2-5 minutos)
2. **Verifica** que no hay errores en los logs
3. **Haz clic en la URL** generada automáticamente
4. **Confirma** que el dashboard carga correctamente

## 🔑 Paso 3: Configurar APIs

### 3.1 Binance API Keys

#### Para Trading Real (Recomendado)
1. **Inicia sesión** en [Binance.com](https://binance.com)
2. **Ve a tu perfil** → Seguridad → Gestión de API
3. **Crea nueva API Key**:
   - **Nombre**: "Crypto Gem Bot Production"
   - **Permisos**: ✅ Lectura + ✅ Spot Trading
   - **⚠️ NO habilites**: Retiros, Futuros, Margen
4. **Copia las claves** y actualiza las variables en Railway

#### Para Modo Demo (Testing)
- Deja las variables con valores por defecto
- El bot funcionará en modo simulación

### 3.2 Telegram Bot

#### Crear Bot de Telegram
1. **Abre Telegram** y busca @BotFather
2. **Envía**: `/newbot`
3. **Sigue las instrucciones**:
   - Nombre del bot: "Mi Crypto Gem Bot"
   - Username: "mi_crypto_gem_bot" (debe terminar en _bot)
4. **Copia el token** que te da BotFather

#### Obtener Chat ID
1. **Busca** @userinfobot en Telegram
2. **Envía** cualquier mensaje
3. **Copia tu Chat ID** (número que empieza con números)

#### Configurar en Railway
1. **Ve a Variables** en tu proyecto Railway
2. **Actualiza**:
   - `TELEGRAM_BOT_TOKEN`: Token de BotFather
   - `TELEGRAM_CHAT_ID`: Tu Chat ID

## 🌐 Paso 4: Configurar Dominio (Opcional)

### Dominio Gratuito de Railway
- Railway te da un dominio automático como: `tu-proyecto.railway.app`
- **Es permanente** y funciona perfectamente
- **SSL incluido** automáticamente

### Dominio Personalizado
1. **Compra un dominio** (ej: GoDaddy, Namecheap)
2. **En Railway**: Settings → Domains → Add Custom Domain
3. **Configura DNS** según las instrucciones de Railway
4. **Espera propagación** (hasta 24 horas)

## ✅ Paso 5: Verificación Final

### 5.1 Test del Dashboard
1. **Abre la URL** de tu bot
2. **Verifica que carga** sin errores
3. **Prueba navegación** entre secciones
4. **Confirma** que los botones responden

### 5.2 Test de Configuración
1. **Ve a Configuración** en el dashboard
2. **Ajusta parámetros** según tu preferencia
3. **Haz clic en "Guardar Configuración"**
4. **Verifica** que aparece mensaje de éxito

### 5.3 Test de Conexiones
1. **Haz clic en "Probar Conexiones"**
2. **Verifica estado**:
   - Binance: ✅ Conectado (si configuraste APIs reales)
   - Telegram: ✅ Conectado (si configuraste bot)
   - DEX: ✅ Conectado (siempre)

### 5.4 Test del Bot
1. **Haz clic en "Iniciar Bot"**
2. **Verifica** que el estado cambia a "Funcionando"
3. **Ve a sección Trades** y verifica que aparecen datos
4. **Ve a sección Alertas** y verifica notificaciones

## 🔧 Paso 6: Configuración Avanzada

### 6.1 Parámetros Recomendados para Principiantes
```
Capital Total: $500-1000
Trades Diarios Máximos: 2-3
Tamaño Máximo Posición: $100-200
Stop Loss: 15-20%
Take Profit 1: 50-100%
Take Profit 2: 150-200%
Confianza Mínima: 90%
```

### 6.2 Parámetros para Usuarios Avanzados
```
Capital Total: $2000-5000
Trades Diarios Máximos: 4-6
Tamaño Máximo Posición: $300-500
Stop Loss: 18%
Take Profit 1: 100%
Take Profit 2: 200%
Take Profit 3: 400%
Confianza Mínima: 85%
```

## 📊 Paso 7: Monitoreo y Mantenimiento

### 7.1 Monitoreo Diario
- **Revisa PnL** cada mañana
- **Verifica alertas** de Telegram
- **Ajusta parámetros** según performance
- **Revisa logs** en Railway si hay problemas

### 7.2 Mantenimiento Semanal
- **Analiza performance** semanal
- **Ajusta estrategia** si es necesario
- **Verifica** que las APIs siguen funcionando
- **Backup** de configuraciones importantes

### 7.3 Actualizaciones
- **Railway actualiza automáticamente** cuando haces push a GitHub
- **Mantén el repositorio** actualizado con mejoras
- **Revisa releases** nuevos del proyecto original

## 🚨 Solución de Problemas Comunes

### Error: "Application failed to start"
**Causa**: Error en el código o dependencias
**Solución**:
1. Revisa logs en Railway
2. Verifica que `requirements.txt` está correcto
3. Confirma que `Procfile` existe

### Error: "Error guardando configuración"
**Causa**: Problema con las APIs del backend
**Solución**:
1. Verifica que el bot está desplegado correctamente
2. Revisa variables de entorno
3. Confirma que la URL funciona

### Error: "Binance API Error"
**Causa**: Claves incorrectas o permisos insuficientes
**Solución**:
1. Verifica que las claves están correctas
2. Confirma permisos en Binance (Lectura + Spot Trading)
3. Revisa que no hay restricciones de IP

### Error: "Telegram Bot Not Found"
**Causa**: Token incorrecto o bot no configurado
**Solución**:
1. Verifica token con @BotFather
2. Confirma que el bot está activo
3. Revisa Chat ID

## 📞 Soporte y Ayuda

### Recursos Oficiales
- **Railway Docs**: [docs.railway.app](https://docs.railway.app)
- **Binance API**: [binance-docs.github.io](https://binance-docs.github.io)
- **Telegram Bots**: [core.telegram.org/bots](https://core.telegram.org/bots)

### Comunidad
- **GitHub Issues**: Para reportar bugs
- **Telegram Group**: Para soporte comunitario
- **Discord**: Para chat en tiempo real

## 🎉 ¡Felicidades!

Si has llegado hasta aquí, tu bot detector de gemas crypto está:
- ✅ **Desplegado** en Railway con dominio real
- ✅ **Funcionando 24/7** sin interrupciones
- ✅ **Configurado** con tus APIs
- ✅ **Listo** para generar ganancias

**¡Que tengas trades exitosos! 🚀💎💰**

---

*Última actualización: Enero 2024*
*Versión de la guía: 2.0*


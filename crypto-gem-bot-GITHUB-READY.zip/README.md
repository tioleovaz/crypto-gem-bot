# 🚀 Crypto Gem Bot - Professional Trading Dashboard

Un bot detector de gemas crypto profesional con dashboard web completo, diseñado para identificar y capitalizar oportunidades de trading en tokens de bajo market cap con alto potencial de crecimiento.

## 🎯 Características Principales

### 🤖 Bot Inteligente de Detección
- **Algoritmo de Confianza Avanzado**: Sistema de scoring que evalúa múltiples métricas para identificar gemas reales
- **Filtros Ultra-Precisos**: Market cap, liquidez, holders, edad del token y momentum social
- **Detección en Tiempo Real**: Monitoreo continuo 24/7 de nuevos tokens y oportunidades
- **Sistema de Priorización**: Clasificación automática de oportunidades por potencial de ganancia

### 📊 Dashboard Profesional
- **Interfaz Moderna**: Dashboard responsive con diseño profesional
- **Control Total**: Iniciar/detener bot, configuración avanzada, monitoreo en tiempo real
- **Métricas Detalladas**: PnL diario, win rate, posiciones activas, capital disponible
- **Historial Completo**: Trades ejecutados, alertas generadas, performance histórica

### 🛡️ Gestión de Riesgo Avanzada
- **Stop Loss Dinámico**: Protección automática con trailing stops
- **Take Profit Escalonado**: Múltiples niveles para maximizar ganancias
- **Límites de Capital**: Control estricto de exposición y riesgo
- **Stop de Emergencia**: Cierre inmediato de todas las posiciones

### 🔗 Integración Completa
- **Binance API**: Trading automático en el exchange más líquido
- **Telegram Alerts**: Notificaciones instantáneas de oportunidades
- **Multi-Red**: Soporte para BSC, Ethereum y otras redes
- **APIs Robustas**: Endpoints RESTful para integración externa

## 🚀 Despliegue Rápido

### Opción 1: Railway (Recomendado)

1. **Fork este repositorio** en tu cuenta de GitHub

2. **Conecta con Railway**:
   - Ve a [Railway.app](https://railway.app)
   - Conecta tu cuenta de GitHub
   - Selecciona este repositorio
   - Railway detectará automáticamente la configuración

3. **Configura Variables de Entorno**:
   ```
   BINANCE_API_KEY=tu_api_key_aqui
   BINANCE_API_SECRET=tu_api_secret_aqui
   TELEGRAM_BOT_TOKEN=tu_bot_token_aqui
   TELEGRAM_CHAT_ID=tu_chat_id_aqui
   ```

4. **Deploy Automático**: Railway desplegará automáticamente y te dará una URL permanente

### Opción 2: Heroku

1. **Clona el repositorio**:
   ```bash
   git clone https://github.com/tu-usuario/crypto-gem-bot.git
   cd crypto-gem-bot
   ```

2. **Instala Heroku CLI** y ejecuta:
   ```bash
   heroku create tu-app-name
   heroku config:set BINANCE_API_KEY=tu_api_key
   heroku config:set BINANCE_API_SECRET=tu_api_secret
   heroku config:set TELEGRAM_BOT_TOKEN=tu_bot_token
   heroku config:set TELEGRAM_CHAT_ID=tu_chat_id
   git push heroku main
   ```

### Opción 3: Local Development

1. **Clona e instala**:
   ```bash
   git clone https://github.com/tu-usuario/crypto-gem-bot.git
   cd crypto-gem-bot
   pip install -r requirements.txt
   ```

2. **Configura variables**:
   ```bash
   cp .env.example .env
   # Edita .env con tus credenciales
   ```

3. **Ejecuta**:
   ```bash
   python app.py
   ```

## ⚙️ Configuración de APIs

### 🔑 Binance API Setup

1. **Inicia sesión** en [Binance.com](https://binance.com)
2. **Ve a Gestión de API** (Perfil → Seguridad → Gestión de API)
3. **Crea nueva API Key**:
   - Nombre: "Crypto Gem Bot"
   - Habilita: ✅ Lectura + ✅ Spot Trading
   - ⚠️ **NO habilites retiros** por seguridad
4. **Copia las claves** y pégalas en el dashboard

### 📱 Telegram Bot Setup

1. **Habla con @BotFather** en Telegram
2. **Crea nuevo bot**: `/newbot`
3. **Sigue las instrucciones** y copia el token
4. **Obtén tu Chat ID**: Habla con @userinfobot
5. **Configura en el dashboard** ambos valores

## 🎯 Estrategia "Gemas Hunter Pro"

### Parámetros Optimizados
- **Capital Total**: $2,000 (configurable)
- **Trades Diarios**: 4 máximo
- **Tamaño por Trade**: $150-300 (7.5-15% del capital)
- **Stop Loss**: 18% (protección base)
- **Take Profit**: 100%, 200%, 400% (escalonado)

### Filtros de Detección
- **Market Cap**: $25K - $300K (sweet spot)
- **Liquidez**: $75K+ mínimo
- **Confianza**: 85%+ requerida
- **Holders**: 150-2000 (distribución saludable)
- **Edad**: 2-72 horas (evitar rugpulls)

### Proyección de Rendimiento
- **ROI Diario**: 20-30% promedio
- **ROI Mensual**: 400-600% conservador
- **Win Rate**: 75% esperado
- **Ganancia Diaria**: $400-600 promedio

## 📊 Uso del Dashboard

### Control del Bot
1. **Iniciar Bot**: Activa la detección automática
2. **Configuración**: Ajusta parámetros según tu perfil de riesgo
3. **Monitoreo**: Observa trades en tiempo real
4. **Alertas**: Recibe notificaciones instantáneas

### Secciones Principales
- **Resumen**: Overview general y métricas clave
- **Trades**: Historial detallado de operaciones
- **Alertas**: Notificaciones y oportunidades detectadas
- **Configuración**: Parámetros del bot y APIs

## 🛡️ Seguridad y Mejores Prácticas

### Seguridad de APIs
- **Nunca habilites retiros** en Binance API
- **Usa IPs restringidas** cuando sea posible
- **Rota las claves** periódicamente
- **Monitorea actividad** regularmente

### Gestión de Riesgo
- **Empieza con capital pequeño** para probar
- **Nunca inviertas más** de lo que puedes perder
- **Usa stop loss** siempre
- **Diversifica** tu portafolio

### Monitoreo
- **Revisa diariamente** el performance
- **Ajusta parámetros** según resultados
- **Mantén logs** de todas las operaciones
- **Backup** de configuraciones importantes

## 🔧 Arquitectura Técnica

### Backend (Flask)
- **Framework**: Flask 3.0 con CORS habilitado
- **APIs RESTful**: Endpoints para todas las funcionalidades
- **Logging**: Sistema completo de logs para debugging
- **Health Checks**: Monitoreo automático para Railway/Heroku

### Frontend (Embedded)
- **Framework**: Tailwind CSS + Lucide Icons
- **Responsive**: Compatible con desktop y mobile
- **Real-time**: Actualización automática cada 30 segundos
- **Interactive**: Tabs, formularios y notificaciones

### Integrations
- **Binance API**: Trading automático y datos de mercado
- **Telegram API**: Alertas y notificaciones
- **DEX APIs**: Datos de tokens y liquidez
- **Chart.js**: Visualización de performance

## 📈 Roadmap y Mejoras Futuras

### Versión 2.0 (Próximamente)
- **Machine Learning**: Algoritmos de predicción avanzados
- **Multi-Exchange**: Soporte para más exchanges
- **Social Sentiment**: Análisis de redes sociales
- **Portfolio Management**: Gestión avanzada de portafolio

### Versión 3.0 (Futuro)
- **DeFi Integration**: Yield farming y liquidity mining
- **NFT Detection**: Identificación de proyectos NFT prometedores
- **Cross-Chain**: Trading en múltiples blockchains
- **Mobile App**: Aplicación nativa para iOS/Android

## 🤝 Contribuciones

¡Las contribuciones son bienvenidas! Por favor:

1. **Fork** el repositorio
2. **Crea una rama** para tu feature (`git checkout -b feature/AmazingFeature`)
3. **Commit** tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. **Push** a la rama (`git push origin feature/AmazingFeature`)
5. **Abre un Pull Request**

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver `LICENSE` para más detalles.

## ⚠️ Disclaimer

**IMPORTANTE**: Este bot es para fines educativos y de investigación. El trading de criptomonedas conlleva riesgos significativos. Nunca inviertas más de lo que puedes permitirte perder. Los resultados pasados no garantizan rendimientos futuros.

## 📞 Soporte

- **Issues**: [GitHub Issues](https://github.com/tu-usuario/crypto-gem-bot/issues)
- **Documentación**: [Wiki del proyecto](https://github.com/tu-usuario/crypto-gem-bot/wiki)
- **Telegram**: [Grupo de soporte](https://t.me/crypto_gem_bot_support)

---

**Desarrollado con ❤️ por la comunidad crypto**

*¡Que tengas trades exitosos! 🚀💎*

